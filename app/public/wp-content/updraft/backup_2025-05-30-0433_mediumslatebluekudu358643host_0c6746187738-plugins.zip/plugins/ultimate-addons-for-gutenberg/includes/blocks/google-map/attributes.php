<?php
/**
 * Attributes File.
 *
 * @since 2.0.0
 *
 * @package uagb
 */

return array(
	'block_id'     => '',
	'height'       => '300',
	'heightTablet' => '300',
	'heightMobile' => '300',
);
