document.addEventListener("DOMContentLoaded", function(){ window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-0a0444f4' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-2d1c8330' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-3c07a954' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-84299f0a' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-8f217925' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-42ed928f' );
});
window.addEventListener("DOMContentLoaded", function(){
	UAGBForms.init( {"block_id":"30bfd676","reCaptchaEnable":false,"reCaptchaType":"v2","reCaptchaSiteKeyV2":"","reCaptchaSecretKeyV2":"","reCaptchaSiteKeyV3":"","reCaptchaSecretKeyV3":"","afterSubmitToEmail":"abc@gmail.com","afterSubmitCcEmail":"","afterSubmitBccEmail":"","afterSubmitEmailSubject":"Form Submission","sendAfterSubmitEmail":true,"confirmationType":"message","hidereCaptchaBatch":false,"captchaMessage":"Please fill up the above captcha.","confirmationUrl":""}, '.uagb-block-30bfd676', 493 );
});
 });